package com.example.vizehesapmakinesi;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    Button buttonac,
            buttonartieksi,
            buttonkare,
            buttonbolme,
            buttonyedi,
            buttonsekiz,
            buttondokuz,
            buttoncarpma,
            buttondort,
            buttonbes,
            buttonalti,
            buttontoplama,
            buttonbir,
            buttoniki,
            buttonuc,
            buttoncikarma,
            buttonsifir,
            buttonf,
            buttonvirgul,
            buttonesittir;

    Double ilksayi;
    TextView hesapekrani;
    Boolean virguldurumu;
    String islemdurumu;

    @SuppressLint("SetTextI18n")
    private void NumaraTikla(int sayi) {
        if (hesapekrani.getText().toString().equals("/") || hesapekrani.getText().toString().equals("*")
                || hesapekrani.getText().toString().equals("+") || hesapekrani.getText().toString().equals("-")
                || hesapekrani.getText().toString().equals("^") || hesapekrani.getText().toString().equals(",")) {
            hesapekrani.setText("");
        }
        hesapekrani.setText(hesapekrani.getText() + String.valueOf(sayi));
    }

    @SuppressLint("SetTextI18n")
    private void SembolTikla(String sembol) {
        switch (sembol) {
            default: {
                if (hesapekrani.getText().toString().equals("/") || hesapekrani.getText().toString().equals("*")
                        || hesapekrani.getText().toString().equals("+") || hesapekrani.getText().toString().equals("-")
                        || hesapekrani.getText().toString().equals("^") || hesapekrani.getText().toString().equals(",")) {
                    if (Objects.equals(islemdurumu, "*") || Objects.equals(islemdurumu, "/")) {
                        ilksayi = -1 * ilksayi;
                    }
                } else {
                    ilksayi = Double.parseDouble(hesapekrani.getText().toString());
                }
                hesapekrani.setText(sembol);
                islemdurumu = String.valueOf(sembol);
            }
            case "ac": {
                ilksayi = 0.0;
                hesapekrani.setText("0");
                islemdurumu = "0";
            }
            case "=": {
                if (hesapekrani.getText().toString().equals("/") || hesapekrani.getText().toString().equals("*")
                        || hesapekrani.getText().toString().equals("+") || hesapekrani.getText().toString().equals("-")
                        || hesapekrani.getText().toString().equals("^") || hesapekrani.getText().toString().equals(",")) {
                } else {
                    switch (islemdurumu) {
                        default: {
                            hesapekrani.setText(ilksayi.toString());
                        }
                        break;
                        case "+": {
                            ilksayi = ilksayi + Double.parseDouble(hesapekrani.getText().toString());
                            hesapekrani.setText(ilksayi.toString());
                        }
                        break;
                        case "-": {
                            ilksayi = ilksayi - Double.parseDouble(hesapekrani.getText().toString());
                            hesapekrani.setText(ilksayi.toString());
                        }
                        break;
                        case "*": {
                            ilksayi = ilksayi * Double.parseDouble(hesapekrani.getText().toString());
                            hesapekrani.setText(ilksayi.toString());
                        }
                        break;
                        case "/": {
                            ilksayi = ilksayi / Double.parseDouble(hesapekrani.getText().toString());
                            hesapekrani.setText(ilksayi.toString());
                        }
                        break;
                        case "^": {
                            ilksayi *= Double.parseDouble(hesapekrani.getText().toString());
                        }
                        break;
                    }
                }
            }
            break;
            case ",": {
                ilksayi = Double.valueOf(ilksayi + "," + Double.parseDouble(hesapekrani.getText().toString()));
            }
            break;
        }
    }



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonac = findViewById(R.id.buttonac);
        buttonartieksi = findViewById(R.id.buttonartieksi);
        buttonkare = findViewById(R.id.buttonkare);
        buttonbolme = findViewById(R.id.buttonbolme);
        buttonyedi = findViewById(R.id.buttonyedi);
        buttonsekiz = findViewById(R.id.buttonsekiz);
        buttondokuz = findViewById(R.id.buttondokuz);
        buttoncarpma = findViewById(R.id.buttoncarpma);
        buttondort = findViewById(R.id.buttondort);
        buttonbes = findViewById(R.id.buttonbes);
        buttonalti = findViewById(R.id.buttonalti);
        buttontoplama = findViewById(R.id.buttontoplama);
        buttonbir = findViewById(R.id.buttonbir);
        buttoniki = findViewById(R.id.buttoniki);
        buttoncikarma = findViewById(R.id.buttoncikarma);
        buttonsifir = findViewById(R.id.buttonsifir);
        buttonf= findViewById(R.id.buttonf);
        buttonuc = findViewById(R.id.buttonuc);
        buttonvirgul = findViewById(R.id.buttonvirgul);
        buttonesittir = findViewById(R.id.buttonesittir);
        buttonartieksi = findViewById(R.id.buttonartieksi);
        
        hesapekrani = findViewById(R.id.hesapekrani);

        hesapekrani.setText("0");
        ilksayi = 0.0;
        virguldurumu = false;
        islemdurumu = "0";

        buttonac.setOnClickListener(v -> SembolTikla("ac") );
        buttonesittir.setOnClickListener(v -> SembolTikla("=") );
        buttonvirgul.setOnClickListener(v -> SembolTikla(",") );
        buttontoplama.setOnClickListener(v -> SembolTikla("+") );
        buttoncikarma.setOnClickListener(v -> SembolTikla("-") );
        buttoncarpma.setOnClickListener(v -> SembolTikla("*") );
        buttonbolme.setOnClickListener(v -> SembolTikla("/") );
        buttonf.setOnClickListener(v -> SembolTikla("f") );
        buttonkare.setOnClickListener(v -> SembolTikla("^") );
        buttonartieksi.setOnClickListener(v -> SembolTikla("+/-") );
        buttonbir.setOnClickListener(v -> NumaraTikla(1));
        buttoniki.setOnClickListener(v -> NumaraTikla(2));
        buttonuc.setOnClickListener(v -> NumaraTikla(3));
        buttondort.setOnClickListener(v -> NumaraTikla(4));
        buttonbes.setOnClickListener(v -> NumaraTikla(5));
        buttonalti.setOnClickListener(v -> NumaraTikla(6));
        buttonyedi.setOnClickListener(v -> NumaraTikla(7));
        buttonsekiz.setOnClickListener(v -> NumaraTikla(8));
        buttondokuz.setOnClickListener(v -> NumaraTikla(9));
        buttonsifir.setOnClickListener(v -> NumaraTikla(0));
    }
}